#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <CL/cl.h>
#include <sys/time.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/stat.h>

#define CHECK_ERROR(err) \
	if (err != CL_SUCCESS) { \
		printf("[%s:%d] OpenCL error %d\n", __FILE__, __LINE__, err); \
		exit(EXIT_FAILURE); \
	}

double get_time() {
	struct timeval tv;
	gettimeofday(&tv, NULL);
	return (double)tv.tv_sec + (double)1e-6 * tv.tv_usec;
}

char *get_source_code(const char *file_name, size_t *len) {
	char *source_code;
	size_t length;
	FILE *file = fopen(file_name, "r");
	if (file == NULL) {
		printf("[%s:%d] Failed to open %s\n", __FILE__, __LINE__, file_name);
		exit(EXIT_FAILURE);
	}

	fseek(file, 0, SEEK_END);
	length = (size_t)ftell(file);
	rewind(file);

	source_code = (char *)malloc(length + 1);
	fread(source_code, length, 1, file);
	source_code[length] = '\0';

	fclose(file);

	*len = length;
	return source_code;
}

void verify(float *A, float *B, float *C, int N);

int main(int argc, char *argv[]) {
	if (argc < 2) {
		printf("Usage: %s <N>\n", argv[0]);
		exit(EXIT_FAILURE);
	}

	int N = atoi(argv[1]);

	float *A = (float*)malloc(sizeof(float) * N * N);
	float *B = (float*)malloc(sizeof(float) * N * N);
	float *C = (float*)malloc(sizeof(float) * N * N);
	int i, j;

	for (i = 0; i < N; i++) {
		for (j = 0; j < N; j++) {
			A[i * N + j] = (float)(rand() % 1000) / 100.0f;
		}
	}
	for (i = 0; i < N; i++) {
		for (j = 0; j < N; j++) {
			B[i * N + j] = (float)(rand() % 1000) / 100.0f;
		}
	}

	printf("Matrix Multiplication\n");
	printf("C[%d X %d] = A[%d X %d] X B[%d X %d]\n", N, N, N, N, N, N);

	cl_platform_id platform;
	cl_device_id device;
	cl_context context;
	cl_command_queue queue;
	cl_program program;
	char *kernel_source;	char *kernel_binary;
	size_t kernel_source_size;	size_t kernel_binary_size;
	cl_kernel kernel_1;
	cl_int err;

	err = clGetPlatformIDs(1, &platform, NULL);
	CHECK_ERROR(err);

	err = clGetDeviceIDs(platform, CL_DEVICE_TYPE_GPU, 1, &device, NULL);
	//err = clGetDeviceIDs(platform, CL_DEVICE_TYPE_CPU, 1, &device, NULL);
	CHECK_ERROR(err);

	context = clCreateContext(NULL, 1, &device, NULL, NULL, &err);
	CHECK_ERROR(err);

	queue = clCreateCommandQueue(context, device, 0, &err);
	CHECK_ERROR(err);


	/*
	kernel_source = get_source_code("kernel.cl", &kernel_source_size);
	program = clCreateProgramWithSource(context, 1, (const char**)&kernel_source,
			&kernel_source_size, &err);
			*/

	/*
	   kernel_binary = get_source_code("kernel.spir64.bc", &kernel_binary_size);
	//kernel_binary = get_source_code("kernel.spir64.ll", &kernel_binary_size);
	program = clCreateProgramWithBinary(context, 1, &device, &kernel_binary_size, (unsigned const char **)&kernel_binary, NULL, &err);
	 */

	kernel_binary = get_source_code("kernel.nvptx.s", &kernel_binary_size);
	program = clCreateProgramWithBinary(context, 1, &device, &kernel_binary_size, (unsigned const char **)&kernel_binary, NULL, &err);

	CHECK_ERROR(err);

	//err = clBuildProgram(program, 1, &device, "-x spir", NULL, NULL);
	err = clBuildProgram(program, 1, &device, "", NULL, NULL);

	if (err == CL_BUILD_PROGRAM_FAILURE) {
		size_t log_size;
		char *log;

		err = clGetProgramBuildInfo(program, device, CL_PROGRAM_BUILD_LOG,
				0, NULL, &log_size);
		CHECK_ERROR(err);

		log = (char*)malloc(log_size + 1);
		err = clGetProgramBuildInfo(program, device, CL_PROGRAM_BUILD_LOG,
				log_size, log, NULL);
		CHECK_ERROR(err);

		log[log_size] = '\0';
		printf("Compiler error:\n%s\n", log);
		free(log);
		exit(-1); 
	}

	CHECK_ERROR(err);

	kernel_1 = clCreateKernel(program, "mat_mul_1", &err);
	CHECK_ERROR(err);

	cl_mem bufA, bufB, bufC;
	bufA = clCreateBuffer(context, CL_MEM_READ_ONLY, sizeof(float) * N * N,
			NULL, &err);
	CHECK_ERROR(err);
	bufB = clCreateBuffer(context, CL_MEM_READ_ONLY, sizeof(cl_float4) * N * N / 4,
			NULL, &err);
	CHECK_ERROR(err);
	bufC = clCreateBuffer(context, CL_MEM_READ_WRITE, sizeof(cl_float4) * N * N / 4,
			NULL, &err);
	CHECK_ERROR(err);

	err = clEnqueueWriteBuffer(queue, bufA, CL_FALSE, 0, sizeof(float) * N * N, A,
			0, NULL, NULL);
	CHECK_ERROR(err);
	err = clEnqueueWriteBuffer(queue, bufB, CL_TRUE, 0, sizeof(cl_float4) * N * N / 4, B,
			0, NULL, NULL);
	CHECK_ERROR(err);

	int lda = N + (64 / sizeof(float));
	int ldb = N + (64 / (4 * sizeof(float)));

	err = clSetKernelArg(kernel_1, 0, sizeof(cl_mem), &bufA);
	CHECK_ERROR(err);
	err = clSetKernelArg(kernel_1, 1, sizeof(cl_mem), &bufB);
	CHECK_ERROR(err);
	err = clSetKernelArg(kernel_1, 2, sizeof(cl_mem), &bufC);
	CHECK_ERROR(err);
	err = clSetKernelArg(kernel_1, 3, sizeof(cl_int), &N);
	CHECK_ERROR(err);
	err = clSetKernelArg(kernel_1, 4, sizeof(cl_int), &lda);
	CHECK_ERROR(err);
	err = clSetKernelArg(kernel_1, 5, sizeof(cl_int), &ldb);

	size_t global_size[2] = {N, N};
	size_t local_size[2] = {16, 16};
	global_size[0] = (global_size[0] + local_size[0] - 1) / local_size[0] * local_size[0];
	global_size[1] = (global_size[1] + local_size[1] - 1) / local_size[1] * local_size[1];
	size_t global_size_odd[2] = {N, N};
	size_t local_size_odd[2] = {16, 12};
	global_size_odd[0] = (global_size_odd[0] + local_size_odd[0] - 1) / local_size_odd[0] * local_size_odd[0];
	global_size_odd[1] = (global_size_odd[1] + local_size_odd[1] - 1) / local_size_odd[1] * local_size_odd[1];

	double start_time, elapsed_time;


	//setting of profiler
	cl_mem counter_buf;
	counter_buf = clCreateBuffer( context, CL_MEM_READ_WRITE, sizeof( int ) * global_size[0] * global_size[1], NULL, &err );
	CHECK_ERROR( err );

	err = clSetKernelArg( kernel_1, 6, sizeof( cl_mem ), &counter_buf);

	start_time = get_time();
	err = clEnqueueNDRangeKernel(queue, kernel_1, 2, NULL, global_size, local_size,
			0, NULL, NULL);
	CHECK_ERROR(err);
	err = clFinish(queue);
	CHECK_ERROR(err);
	elapsed_time = get_time() - start_time;
	printf("mat_mul_1 (16x16) - elapsed time: %f msec (%f GFLOPS)\n", elapsed_time * 1000,
			(double)N * N * (N * 2 - 1) / 1e+9 / elapsed_time);

	//profilier
	int * count_arr = ( int * )malloc( sizeof( int ) * global_size[0] * global_size[1] );
	err = clEnqueueReadBuffer( queue, counter_buf, CL_TRUE, 0, sizeof( int ) * global_size[0] * global_size[1], count_arr , 0, NULL, NULL );
	CHECK_ERROR( err );

	unsigned long long int total_add = 0;
	for( int i=0; i< global_size[0]*global_size[1]; ++i)
	{
		total_add += count_arr[i];
	}

	printf("Total Add To Execute : %lld\n", total_add );


	/*

	   start_time = get_time();
	   err = clEnqueueNDRangeKernel(queue, kernel_1, 2, NULL, global_size_odd, local_size_odd,
	   0, NULL, NULL);
	   CHECK_ERROR(err);
	   err = clFinish(queue);
	   CHECK_ERROR(err);
	   elapsed_time = get_time() - start_time;
	   printf("mat_mul_1 (16x12) - elapsed time: %f msec (%f GFLOPS)\n", elapsed_time * 1000,
	   (double)N * N * (N * 2 - 1) / 1e+9 / elapsed_time);

	   start_time = get_time();
	   err = clEnqueueNDRangeKernel(queue, kernel_2, 2, NULL, global_size, local_size,
	   0, NULL, NULL);
	   CHECK_ERROR(err);
	   err = clFinish(queue);
	   CHECK_ERROR(err);
	   elapsed_time = get_time() - start_time;
	   printf("mat_mul_2 (16x16) - elapsed time: %f msec (%f GFLOPS)\n", elapsed_time * 1000,
	   (double)N * N * (N * 2 - 1) / 1e+9 / elapsed_time);

	   start_time = get_time();
	   err = clEnqueueNDRangeKernel(queue, kernel_3, 2, NULL, global_size, local_size,
	   0, NULL, NULL);
	   CHECK_ERROR(err);
	   err = clFinish(queue);
	   CHECK_ERROR(err);
	   elapsed_time = get_time() - start_time;
	   printf("mat_mul_3 (16x16) - elapsed time: %f msec (%f GFLOPS)\n", elapsed_time * 1000,
	   (double)N * N * (N * 2 - 1) / 1e+9 / elapsed_time);
	 */

	err = clEnqueueReadBuffer(queue, bufC, CL_TRUE, 0, sizeof(cl_float4) * N * N / 4, C,
			0, NULL, NULL);
	CHECK_ERROR(err);

	if (N <= 1000) {
		verify(A, B, C, N);
	}

	clReleaseMemObject(bufA);
	clReleaseMemObject(bufB);
	clReleaseMemObject(bufC);
	clReleaseKernel(kernel_1);
	clReleaseProgram(program);
	clReleaseCommandQueue(queue);
	clReleaseContext(context);

	free(A);
	free(B);
	free(C);
	return 0;
}

void verify(float *A, float *B, float *C, int N) {
	int i, j, k;
	float sum;

	for (i = 0; i < N; i++) {
		for (j = 0; j < N; j++) {
			sum = 0.0f;
			for (k = 0; k < N; k++) {
				sum += A[i * N + k] * B[k * N + j];
			}
			if (fabsf(C[i * N + j] - sum) > 0.1) {
				printf("Verification failed! C[%d][%d]: %f vs. %f\n",
						i, j, C[i * N + j], sum);
				return;
			}
		}
	}
	printf("Verification success!\n");
}
