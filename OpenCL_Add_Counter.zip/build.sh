#!/bin/bash

clang++ -g -emit-llvm -c -I ./include -o ./lib/template.bc ./lib/template.cl

clang++ -g -std=c++11 -I ./include -c -o ./obj/counter.o ./src/counter.cpp $(llvm-config --cxxflags)
clang++ -g -std=c++11 -I ./include -c -o ./obj/utils.o ./src/utils.cpp $(llvm-config --cxxflags)
clang++ -g -std=c++11 -I ./include -c -o ./obj/normal.o ./src/normal.cpp $(llvm-config --cxxflags)
clang++ -g -std=c++11 -I ./include -c -o ./obj/insert.o ./src/insert.cpp $(llvm-config --cxxflags)
clang++ -g -std=c++11 -I ./include -c -o ./obj/replace.o ./src/replace.cpp $(llvm-config --cxxflags)

g++ -o ./normal ./obj/counter.o ./obj/utils.o ./obj/normal.o $(llvm-config --ldflags --libs mcjit x86 --system-libs)
g++ -o ./insert ./obj/counter.o ./obj/utils.o ./obj/insert.o $(llvm-config --ldflags --libs mcjit x86 --system-libs)
g++ -o ./replace ./obj/counter.o ./obj/utils.o ./obj/replace.o $(llvm-config --ldflags --libs mcjit x86 --system-libs)
