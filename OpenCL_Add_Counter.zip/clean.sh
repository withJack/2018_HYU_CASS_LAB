#!/bin/bash

rm -f normal
rm -f replace
rm -f insert

rm -f ./test/kernel.bc
rm -f ./test/kernel.linked.bc
rm -f ./test/kernel.linked.modified.bc
rm -f ./test/kernel.linked.modified.linked.bc
rm -f ./test/kernel.nvptx.s
rm -f ./test/matmul

rm -f ./obj/*

rm -f ./lib/template.bc
