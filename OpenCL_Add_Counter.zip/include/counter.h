#ifndef OPENCL_ADD_COUNTER_H_
#define OPENCL_ADD_COUNTER_H_

extern std::string kernel_bitcode_path;

int get_module(std::string& error_msg);
int instruction_insertion( std::string& error_msg );
int instruction_modification( std::string& error_msg );
int instruction_count( std::string& error_msg );
int module_writing( std::string& error_msg );

#endif //OPENCL_ADD_COUNTER_H_
