
#ifndef OPENCL_PROFILER_TEMPLATE_H_
#define OPENCL_PROFILER_TEMPLATE_H_

#define STRCON( X, Y ) X ## Y
#define STR_OF_SYMBOL( X ) #X
#define QUOTE( X ) #X
#define STR_OF_VALUE( X ) QUOTE( X )

#define INCREASE_TEMPLATE_FUNC		counter_increase_func	

#endif
