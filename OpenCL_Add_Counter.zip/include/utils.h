#ifndef OPENCL_PROFILER_UTILS_H_
#define OPENCL_PROFILER_UTILS_H_

#include <string>
#include <vector>
#include "llvm/IR/Metadata.h"

#define UTIL_RETURN_ERROR -1
#define UTIL_RETURN_NORMAL 0

//------- Parsing Paths -------
std::string dir_of( std::string path );
std::string ext_of( std::string path );
std::string name_of( std::string path );

//------- Fork & Exec ------
int command_exec( int num_of_commands, std::string commands[] );
int command_exec( int num_fo_commands, char* commmands[] );
int command_exec( std::vector< std::string >& commands );
int command_exec( std::vector< char* >& commands );

//-------- Read File -------
int read_file( std::string& path, std::string& dest );

//-------- Metadata Modification -------
llvm::MDNode* merge_mdnode( llvm::LLVMContext& TheContext, llvm::MDNode* first, llvm::MDNode* second );
llvm::MDNode* append_mdnode( llvm::LLVMContext& TheContext, llvm::MDNode* node, llvm::Metadata* element );

#endif
