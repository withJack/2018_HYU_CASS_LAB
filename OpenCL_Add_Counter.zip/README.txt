# Do $sh run.sh
# normal, insert, replace : LLVM IR -> LLVM IR
