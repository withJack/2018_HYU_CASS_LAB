#!/bin/bash

TARGET_TRIPLE=-nvptx64-nvidia-nvcl
TARGET_CPU=sm_20
TARGET_ARCH=nvptx64
LIBCLC_HEADER_PATH=/usr/local/libclc/include/clc/clc.h
LIBCLC_LIB_PATH=/usr/local/libclc/lib/clc/nvptx64--nvidiacl.bc

# 1. Build OpenCL Add Counter Program( Modifier )
# 1.1 Compile OpenCL Template Functions( increase functions ) To LLVM Bitcode
clang++ -g -emit-llvm -c -I ./include -o ./lib/template.bc ./lib/template.cl
# 1.2 Build OpenCL Add Counter Program( Normal Counter )
sh build.sh

# 2. Build Test Matmul Kernel
# 2.1 Build OpenCL Host Program
gcc ./test/matmul.c -o ./test/matmul -lOpenCL
# 2.2 Build OpenCL Kernel Program To Binary
# 2.2.1 Compile OpenCL Kernel To LLVM IR
clang++ -emit-llvm -c -target $TARGET_TRIPLE -Dcl_clang_storage_class_specifiers -include $LIBCLC_HEADER_PATH -fpack-struct=64 -o ./test/kernel.bc ./test/kernel.cl
# 2.2.2 IR-level Link between OpenCL Kernel and Template Functions
llvm-link -o ./test/kernel.linked.bc ./test/kernel.bc ./lib/template.bc

# 3. Normal(Origianl) Add Instructions
# 3.1 Use OpenCL Add Counter Program
# Normal
./normal ./test/kernel.linked.bc
# 3.2 IR-level Link between Modified Kernel IR and libclc lib
llvm-link -o ./test/kernel.linked.modified.linked.bc ./test/kernel.linked.modified.bc $LIBCLC_LIB_PATH
# 3.3 LLVM Static Compile To NVPTX
llc -o ./test/kernel.nvptx.s -mcpu=$TARGET_CPU -march=$TARGET_ARCH ./test/kernel.linked.modified.linked.bc
# 3.4 Run
cd ./test
echo "=========== Normal Cases ==========="
./matmul 100
echo "===================================="
cd ../

# 4. Insert One Add Instruction
# 4.1 Use OpenCL Add Counter Program
# Insert
./insert ./test/kernel.linked.bc
# 4.2 IR-level Link between Modified Kernel IR and libclc lib
llvm-link -o ./test/kernel.linked.modified.linked.bc ./test/kernel.linked.modified.bc $LIBCLC_LIB_PATH
# 4.3 LLVM Static Compile To NVPTX
llc -o ./test/kernel.nvptx.s -mcpu=$TARGET_CPU -march=$TARGET_ARCH ./test/kernel.linked.modified.linked.bc
# 4.4 Run
cd ./test
echo "=========== Insert Cases ==========="
./matmul 100
echo "===================================="
cd ../


# 5. Replace One Add Instruction To Sub Instruction
# 4.1 Use OpenCL Add Counter Program
# Insert
./replace ./test/kernel.linked.bc
# 4.2 IR-level Link between Modified Kernel IR and libclc lib
llvm-link -o ./test/kernel.linked.modified.linked.bc ./test/kernel.linked.modified.bc $LIBCLC_LIB_PATH
# 4.3 LLVM Static Compile To NVPTX
llc -o ./test/kernel.nvptx.s -mcpu=$TARGET_CPU -march=$TARGET_ARCH ./test/kernel.linked.modified.linked.bc
# 4.4 Run
cd ./test
echo "=========== Replace Cases ==========="
./matmul 100
echo "===================================="
cd ../
