#include <iostream>
#include <fstream>
#include <string>
#include <vector>

#include "llvm/IR/IRBuilder.h"
#include "llvm/IR/LLVMContext.h"
#include "llvm/IR/Module.h"
#include "llvm/IR/Metadata.h"
#include "llvm/IR/Instruction.h"
#include "llvm/IR/BasicBlock.h"
#include "llvm/IR/Function.h"
#include "llvm/Bitcode/BitcodeReader.h"
#include "llvm/Bitcode/BitcodeWriter.h"
#include "llvm/Transforms/Utils/ValueMapper.h"
#include "llvm/Transforms/Utils/Cloning.h"
#include "llvm/Transforms/Utils/BasicBlockUtils.h"

#include "counter.h"
#include "utils.h"
#include "template.h"

llvm::LLVMContext TheContext;
std::unique_ptr< llvm::Module > TheModule;
llvm::IRBuilder<>* TheBuilder = new llvm::IRBuilder<>(TheContext);
std::string kernel_bitcode_path = "";

int get_module(std::string& error_msg)
{
	std::string kernel_bitcode_contents;

	if( read_file( kernel_bitcode_path, kernel_bitcode_contents ) == UTIL_RETURN_ERROR
			|| kernel_bitcode_contents == "" )
	{
		//print_usage( std::string("Read File Failed: ") + kernel_bitcode_path );
		error_msg = std::string("Read File Failed:") + kernel_bitcode_path;
		return -1;
	}

	llvm::MemoryBufferRef kernel_bitcode_contents_mbref( llvm::StringRef( kernel_bitcode_contents ), "kernel_membuf" );
	auto expected_unq_ptr_module = llvm::parseBitcodeFile( kernel_bitcode_contents_mbref, TheContext );

	if( !expected_unq_ptr_module )
	{
		//print_usage( std::string("Parse Bitcode File Error: ") + kernel_bitcode_path );
		error_msg = std::string("Parse Bitcode File Error: ") + kernel_bitcode_path;
		return -1;
	}

	TheModule = std::move(expected_unq_ptr_module.get());

	return 0;
}

//insert a add instruction in kernel function
int instruction_insertion( std::string& error_msg )
{
	//get target functions( mat_mul_1 )
	llvm::Function* kernel_function= TheModule->getFunction( "mat_mul_1" );

	if( kernel_function == NULL )
	{
		error_msg = std::string( "kernel function not found" );
		return -1;
	}

	//set insert point
	llvm::Instruction* first_inst = llvm::cast< llvm::Instruction >( kernel_function->begin()->begin() );
	TheBuilder->SetInsertPoint( first_inst );

	//add lda + 1
	TheBuilder->CreateAdd( kernel_function->arg_begin() + 4, llvm::ConstantInt::get( llvm::Type::getInt32Ty( TheContext ), 1, true ), "lda_plus_1_tmp" );
	
	return 0;
}

//modify a add instuction to sub instruction in kernel function
int instruction_modification( std::string& error_msg )
{
	//get target functions( mat_mul_1 )
	llvm::Function* kernel_function= TheModule->getFunction( "mat_mul_1" );
	bool find =false;

	if( kernel_function == NULL )
	{
		error_msg = std::string( "kernel function not found" );
		return -1;
	}

	
	for( llvm::Function::iterator FuncIter = kernel_function->begin();
			FuncIter != kernel_function->end();
			++FuncIter )
	{
		llvm::BasicBlock* BB = llvm::cast< llvm::BasicBlock >( FuncIter );
		//llvm::BaiscBlock* BB = &(*FuncIter);

		for( llvm::BasicBlock::iterator BBIter = BB->begin();
				BBIter != BB->end();
				++BBIter )
		{
			llvm::Instruction* Inst = llvm::cast< llvm::Instruction >( BBIter );

			if( Inst->getOpcode() == llvm::Instruction::Add )
			{
				if( Inst->isBinaryOp() )
				{
					llvm::ReplaceInstWithInst(
							Inst,
							llvm::cast<llvm::Instruction>(TheBuilder->CreateSub( Inst->getOperand(0), Inst->getOperand(1), "subtmp"))
							);

					break;
					find = true;
				}
			}
		}
		
		if( find )
			break;
	}

	return 0;
}

//insert call instructions before add instructions in kernel function
int instruction_count( std::string& error_msg )
{
	//get llvm::Function obj of get_gloal_id() and get_global_size()
	llvm::Function* get_global_id_func, *get_global_size_func;

	get_global_id_func = TheModule->getFunction( "get_global_id" );
	get_global_size_func = TheModule->getFunction( "get_global_size" );

	if( get_global_id_func == NULL )
	{
		llvm::Type* get_global_id_return_type = llvm::IntegerType::get( TheContext, sizeof( size_t ) * 8 );
		std::vector< llvm::Type* > get_global_id_param_types;
		get_global_id_param_types.clear();
		get_global_id_param_types.push_back( llvm::IntegerType::get( TheContext, sizeof( unsigned int ) * 8 ) );
		llvm::FunctionType* get_global_id_func_type = llvm::FunctionType::get( get_global_id_return_type, get_global_id_param_types, false );

		get_global_id_func = llvm::Function::Create(  get_global_id_func_type, llvm::Function::ExternalLinkage, "get_global_id", TheModule.get() );
	}

	if( get_global_size_func == NULL )
	{
		llvm::Type* get_global_size_return_type = llvm::IntegerType::get( TheContext, sizeof( size_t ) * 8 );
		std::vector< llvm::Type* > get_global_size_param_types;
		get_global_size_param_types.clear();
		get_global_size_param_types.push_back( llvm::IntegerType::get( TheContext, sizeof( unsigned int ) * 8 ) );
		llvm::FunctionType* get_global_size_func_type = llvm::FunctionType::get( get_global_size_return_type, get_global_size_param_types, false );
		
		get_global_size_func = llvm::Function::Create(  get_global_size_func_type, llvm::Function::ExternalLinkage, "get_global_size", TheModule.get() );
	}

	if( get_global_id_func == NULL
			|| get_global_size_func == NULL )
	{
		error_msg = std::string( "opencl built-in functions not found" );
		return -1;
	}

	//get template funcitons
	llvm::Function* increase_template_func = TheModule->getFunction( STR_OF_VALUE( INCREASE_TEMPLATE_FUNC ) );

	if( increase_template_func == NULL )
	{
		error_msg = std::string( "increase template function not found" );
		return -1;
	}

	//get target functions( mat_mul_1 )
	llvm::Function* kernel_function= TheModule->getFunction( "mat_mul_1" );

	if( kernel_function == NULL )
	{
		error_msg = std::string( "kernel function not found" );
		return -1;
	}

	//other variables
	std::vector< llvm::Value* > function_call_args;
	std::vector< llvm::Instruction* > kernel_function_instruction_vector;
	llvm::Value *global_id_0, *global_id_1, *global_id_2;
	llvm::Value *global_size_0, *global_size_1, *global_size_2;
	llvm::Value *dynPfStruct, *tid;


	//get original instructions 
	kernel_function_instruction_vector.clear();
	for( llvm::Function::iterator funcIter = kernel_function->begin();
			funcIter != kernel_function->end();
			++funcIter )
	{
		llvm::BasicBlock* kernel_bb = llvm::cast<llvm::BasicBlock>( funcIter );
		for( llvm::BasicBlock::iterator BBIter = kernel_bb->begin();
				BBIter != kernel_bb->end();
				++BBIter )
		{
			llvm::Instruction* inst = llvm::cast<llvm::Instruction>(BBIter);
			kernel_function_instruction_vector.push_back( inst );
		}
	}

	//set insert point
	llvm::Instruction* first_inst = llvm::cast< llvm::Instruction >( kernel_function->begin()->begin() );
	TheBuilder->SetInsertPoint( first_inst );


	//get global thread id
	dynPfStruct = llvm::cast<llvm::Value>( kernel_function->arg_end() -1 );
	llvm::Type* template_struct_type = increase_template_func->getFunctionType()->params()[0];
	dynPfStruct = TheBuilder->CreatePointerCast( dynPfStruct, template_struct_type );

	function_call_args.clear();
	function_call_args.push_back( llvm::ConstantInt::get( llvm::Type::getInt32Ty( TheContext ), 0, true ) );
	global_id_0 = TheBuilder->CreateCall( get_global_id_func, function_call_args, "call.get_global_id.0" );

	function_call_args.clear();
	function_call_args.push_back( llvm::ConstantInt::get( llvm::Type::getInt32Ty( TheContext ), 1, true ) );
	global_id_1 = TheBuilder->CreateCall( get_global_id_func, function_call_args, "call.get_global_id.1" );

	function_call_args.clear();
	function_call_args.push_back( llvm::ConstantInt::get( llvm::Type::getInt32Ty( TheContext ), 2, true ) );
	global_id_2 = TheBuilder->CreateCall( get_global_id_func, function_call_args, "call.get_global_id.2" );

	//function_call_args.clear();
	//function_call_args.push_back( llvm::ConstantInt::get( llvm::Type::getInt32Ty( TheContext ), 0, true ) );
	//global_size_0 = TheBuilder->CreateCall( get_global_size_func, function_call_args, "call.get_global_size.2" );

	function_call_args.clear();
	function_call_args.push_back( llvm::ConstantInt::get( llvm::Type::getInt32Ty( TheContext ), 1, true ) );
	global_size_1= TheBuilder->CreateCall( get_global_size_func, function_call_args, "call.get_global_size.2" );

	function_call_args.clear();
	function_call_args.push_back( llvm::ConstantInt::get( llvm::Type::getInt32Ty( TheContext ), 2, true ) );
	global_size_2 = TheBuilder->CreateCall( get_global_size_func, function_call_args, "call.get_global_size.2" );


	tid = TheBuilder->CreateMul( TheBuilder->CreateMul( global_id_0, global_size_1 ), global_size_2 );
	tid = TheBuilder->CreateAdd( tid, TheBuilder->CreateMul( global_id_1, global_size_2 ) );
	tid = TheBuilder->CreateAdd( tid, global_id_2 );

	llvm::Type* template_int_type = increase_template_func->getFunctionType()->params()[1];
	tid = TheBuilder->CreateIntCast( tid, template_int_type, false );

	//set template function call arguments
	function_call_args.clear();
	function_call_args.push_back( dynPfStruct );
	function_call_args.push_back( tid );


	for( std::vector< llvm::Instruction* >::iterator InstVecIter = kernel_function_instruction_vector.begin();
			InstVecIter != kernel_function_instruction_vector.end();
			++InstVecIter
	   )
	{
		llvm::Instruction* Inst = *InstVecIter;
		TheBuilder->SetInsertPoint( Inst );

		if( Inst->getOpcode() == llvm::Instruction::Add )
		{
			TheBuilder->CreateCall( increase_template_func, function_call_args );
		}
	}

	return 0;
}

int module_writing( std::string& error_msg )
{
	std::string bitcode_string;
	llvm::raw_string_ostream bitcode_string_ostream( bitcode_string );
	llvm::WriteBitcodeToFile( TheModule.get(), bitcode_string_ostream );
	bitcode_string_ostream.flush();

	std::string kernel_dir_path = dir_of( kernel_bitcode_path );
	std::string kernel_source_name = name_of( kernel_bitcode_path );
	std::string output_file_path = kernel_dir_path + kernel_source_name + ".modified.bc";
	std::ofstream output_file( output_file_path );

	if( !output_file.good() )
	{
		error_msg = "File Open Error: " + output_file_path;
		return -1;
	}

	output_file << bitcode_string;
	output_file.close();

	return 0;
}


