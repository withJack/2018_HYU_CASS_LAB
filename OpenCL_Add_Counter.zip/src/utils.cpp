#include <string>
#include <fstream>

#include <cstdlib>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>

#include "utils.h"

std::string dir_of( std::string path )
{
	size_t last_slash_pos = path.rfind("/");
	if( last_slash_pos == std::string::npos )
		return "";

	return path.substr( 0, last_slash_pos + 1 );
}

std::string ext_of( std::string path )
{
	size_t last_dot_pos = path.rfind(".");
	if( last_dot_pos == std::string::npos )
		return "";

	return path.substr( last_dot_pos + 1, std::string::npos );
}

std::string name_of( std::string path )
{
	size_t last_slash_pos = path.rfind("/");
	size_t last_dot_pos = path.rfind(".");

	if( last_slash_pos == std::string::npos )
		last_slash_pos = -1;
	if( last_dot_pos == std::string::npos )
		last_dot_pos = -1;

	return path.substr( last_slash_pos + 1, last_dot_pos - last_slash_pos -1 );
}

int command_exec( int ncmds, std::string cmds[] )
{
	int i, retval;
	char ** cmds_cstr = new char*[ncmds];
	for( i=0; i<ncmds; ++i)
	{
		cmds_cstr[i] = const_cast<char*>( cmds[i].c_str() );
	};

	retval = command_exec( ncmds, cmds_cstr );

	delete [] cmds_cstr;

	return retval;
}

int command_exec( int ncmds, char* cmds[] )
{
	pid_t pid;

	if( ( pid = fork() ) == 0)
	{
		//child
		int i;
		char ** cmds_cstr = new char*[ncmds+1];
		for( i = 0; i < ncmds; ++i )
		{
			cmds_cstr[i] = cmds[i];
		}
		cmds_cstr[ncmds] = (char*) NULL;

		execvp( cmds_cstr[0], cmds_cstr );

		exit(-1);
	}
	else
	{
		//parent
		int status;

		waitpid( pid, &status, 0 );

		if( WEXITSTATUS(status) != 0 )
		{
			return WEXITSTATUS(status);
		}
	}

	return UTIL_RETURN_NORMAL;
}

/*
int command_exec( int ncmds, char* cmds[] )
{
	int i, retval;
	std::string* str_commands = new std::string[ncmds];

	for( i=0; i<ncmds; ++i )
	{
		str_commands[i] = std::string(cmds[i]);
	}

	retval = command_exec( ncmds, str_commands );

	delete [] str_commands;

	return retval;
}
*/

int command_exec( std::vector< std::string >& cmds )
{
	int i, retval, ncmds;

	ncmds = cmds.size();
	std::string * str_commands = new std::string[ncmds];

	for( i=0; i< ncmds; ++i)
	{
		str_commands[i] = cmds[i];
	}

	retval = command_exec( ncmds, str_commands );

	delete [] str_commands;

	return retval;
}

int read_file( std::string& path, std::string& dest )
{
	std::ifstream file_stream(path.c_str());

	if( file_stream.fail() )
	{
		//file open failed
		dest = "";
		return UTIL_RETURN_ERROR;
	}

	dest.assign( 
			(std::istreambuf_iterator< char >( file_stream )),
			(std::istreambuf_iterator< char > ())
			);

	file_stream.close();

	return UTIL_RETURN_NORMAL;
}


llvm::MDNode* merge_mdnode( llvm::LLVMContext& TheContext, llvm::MDNode* first, llvm::MDNode* second )
{
	std::vector< llvm::Metadata * > mdList;
	mdList.clear();

	for( llvm::MDNode::op_iterator OPIter = first->op_begin();
			OPIter != first->op_end();
			++OPIter )
	{
		const llvm::MDOperand * operand = &(*OPIter);
		llvm::Metadata * operand_metadata = operand->get();
		mdList.push_back( operand_metadata );		
	}

	for( llvm::MDNode::op_iterator OPIter = second->op_begin();
			OPIter != second->op_end();
			++OPIter )
	{
		const llvm::MDOperand * operand = &(*OPIter);
		llvm::Metadata * operand_metadata = operand->get();
		mdList.push_back( operand_metadata );
	}

	return llvm::MDNode::get( TheContext, llvm::ArrayRef<llvm::Metadata*>( mdList ) );
}

llvm::MDNode* append_mdnode( llvm::LLVMContext& TheContext, llvm::MDNode* node, llvm::Metadata* element )
{
	std::vector< llvm::Metadata * > mdList;
	mdList.clear();

	for( llvm::MDNode::op_iterator OPIter = node->op_begin();
			OPIter != node->op_end();
			++OPIter )
	{
		const llvm::MDOperand * operand = &(*OPIter);
		llvm::Metadata * operand_metadata = operand->get();
		mdList.push_back( operand_metadata );		
	}

	mdList.push_back( element );

	return llvm::MDNode::get( TheContext, llvm::ArrayRef<llvm::Metadata*>( mdList ) );
}
