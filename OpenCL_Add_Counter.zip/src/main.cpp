#include <iostream>
#include <string>

#include "counter.h"

int main(int argc, char* argv[])
{
	if( argc < 2 )
	{
		std::cout << argv[0] << " opencl_bitcode_path" << std::endl;
		return 0;
	}

	kernel_bitcode_path = std::string( argv[1] );

	std::string error_msg = "";

	if( get_module( error_msg ) < 0 )
	{
		std::cerr << error_msg << std::endl;
		return 0;
	}

	if( instruction_count( error_msg ) )
	{
		std::cerr << error_msg << std::endl;
		return 0;
	}

	if( module_writing( error_msg ) )
	{
		std::cerr << error_msg << std::endl;
		return 0;
	}

	return 0;
}
